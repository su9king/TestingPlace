document.getElementById('loadContent').addEventListener('click', function() {
    loadIndex2Content();
});

function loadIndex2Content() {
    fetch('index2.html')
        .then(response => {
            if (!response.ok) {
                throw new Error('네트워크 응답 X');
            }
            return response.text();
        })
        .then(data => {
            document.getElementById('content').innerHTML = data;
            // index2.js의 초기화 함수 호출
            initializeIndex2();
        })
        .catch(error => {
            console.error('문제가 발생했습니다:', error);
        });
}
