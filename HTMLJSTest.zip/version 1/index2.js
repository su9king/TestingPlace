document.getElementById('actionButton').addEventListener('click', function() {
    alert('index2.js와 통신');  
});
