document.getElementById('loadContent').addEventListener('click', function() {
    document.getElementById('iframeContent').src = 'index2.html';
});
